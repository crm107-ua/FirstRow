# Comentarios entrega 02 FirstRow

Sencillamente perfecta. Los tag bien, milestone bien, simplemente recordaros que debeis poner los DNI en los commits. En el proyecto, asignar las tareas por usuario. Pero vamos que esta genial.

Enhorabuena y seguid así.